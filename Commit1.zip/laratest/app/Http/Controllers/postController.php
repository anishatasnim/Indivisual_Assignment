<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;

class postController extends Controller
{
    public function index(Request $req){
    	$category = DB::table('category')->get();
    	return view('home.post',compact('category'));

    }
    public function storepost(Request $req){
    	$data=array();
    	$data['title']=$req->title;
    	$data['category_id']=$req->category_id;
    	$data['details']=$req->details;
    	DB::table('post')->insert($data);
    	return Redirect()->back();

    	}

    
    public function all(){
        // $post=DB::table('post')->get();
        $post=DB::table('post')
        ->join('category','post.category_id','category.id')
        ->select('post.*','category.category_name')
        ->get();

        return view('home.show_all_post',compact('post'));
    }
    public function viewpost($id){
        $post=DB::table('post')
        ->join('category','post.category_id','category.id')
        ->select('post.*','category.category_name')
        ->where('post.id',$id)
        ->first();
        // print_r($post);
        return view('home.view_post',compact('post'));
    }
    public function edit($id){
        
        $post=DB::table('post')->where('id',$id)->first();
        $category=DB::table('category')->get();
        return view('home.edit_post',compact('category','post'));
    }
    public function update(Request $req,$id){
        $data=array();
        $data['title']=$req->title;
        $data['category_id']=$req->category_id;
        $data['details']=$req->details;
          
            DB::table('post')->where('id',$id)->update($data);
            return Redirect()->route('post.all');

        

    }
    public function delete($id){
        $delete=DB::table('post')->where('id',$id)->delete();
        return Redirect()->route('post.all');

    
}}
