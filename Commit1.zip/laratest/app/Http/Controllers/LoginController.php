<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;


class LoginController extends Controller
{
    public function index(Request $req){
    	return view ('login.index');
    }
    public function verify(Request $req){

    	$user = DB::table('users')
                    ->where('uname', $req->uname)
                    ->where('password', $req->password)
                    ->first();
    	if($user != null){
            if($user->type == "admin"){
            $req->session()->put('uname', $req->uname);
    		return redirect()->route('home.index');
        }
        elseif($user->type == "user"){
                $req->session()->put('uname', $req->uname);
                return redirect()->route('user.index');
        }

    	}else{
            $req->session()->flash('msg', 'invalid username or password');
            return redirect('/login');
    	}
    	

    }
}
