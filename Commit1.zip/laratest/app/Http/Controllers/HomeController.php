<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\HomeRequest;
use Validator;

class HomeController extends Controller
{

    public function index(Request $req){

        
        if($req->session()->has('uname')){
            return view('home.index');
        }else{
            return redirect('/login');
        }
    }   

    public function show($id){

        $user = User::find($id);
        return view('home.details', $user);
    }
    
    public function addUser(Request $req){

        $data=array();
        
        $data['uname']=$req->uname;
        $data['password']=$req->password;
        $data['gender']=$req->gender;
        $data['email']=$req->email;
        $data['type']=$req->type;
        DB::table('users')->insert($data);
       if($data->save()){
            return redirect()->route('home.list');
        }else{
            return redirect()->route('home.index');
        }

    }

    public function insert(Request $req){

        $req->validate([
            'uname'=>'bail|required|min:5|unique:users',
            'password'=>'required',
            'gender' => 'required',
            'email'    =>'required',
            'typr' =>'required'
        ]);

        $user = DB::table('users')->get();
        return view('home.list');

        /*$validation = $this->validate($req, [
            'username'=>'bail|required|min:5|unique:users',
            'password'=>'required',
            'name'=>'required',
            'cgpa'=>'required'
        ])->validate();*/

        //$validation->validate();

/*      $validation = Validator::make($req->all(), [
            'username'=>'bail|required|min:5|unique:users',
            'password'=>'required',
            'name'=>'required',
            'cgpa'=>'required'
        ]);

        if($validation->fails()){
            return back()
                    ->with('errors', $validation->errors())
                    ->withInput();

            return redirect()->route('home.add')
                            ->with('errors', $validation->errors())
                            ->withInput();      
        }*/

        $user           = new User;
        $user->username = $req->username;
        $user->password = $req->password;
        $user->gender   = $req->gender;
        $user->email    = $req->email;
        $user->type     = $req->type;


        if($user->save()){
            return redirect()->route('home.list');
        }else{
            return redirect()->route('home.addUser');
        }

        if($req->hasFile('pic')){
            $file = $req->file('pic');
            echo "File Name: ". $file->getClientOriginalName()."<br>";
            echo "File Extension: ". $file->getClientOriginalExtension()."<br>";
            echo "File Size: ". $file->getSize()."<br>";
            echo "File Mime Type: ". $file->getMimeType();

            if($file->move('upload', "abc.".$file->getClientOriginalExtension())){
                echo "<h1>success</h1>";
            }else{
                echo "<h1>Error!</h1>";
            }

        }else{
            echo "File not found!";
        }
    }

    public function edit($id){
    
        /*$students = $this->getStudentList();
        $std="";
        for($i=0; $i< count($students); $i++){
            if($students[$i]['id'] == $id){
                $std = $students[$i];
                break;
            }
        }*/

        $user = User::find($id);
        return view('home.edit', $user);
    }

    public function update($id, Request $req){
        $user = User::find($id);
        $user->username = $req->username;
        $user->password = $req->password;
        $user->gender   = $req->gender;
        $user->email    = $req->email;
        $user->type     = $req->type;
        
        
        if($user->save()){
            return redirect()->route('home.list');
        }else{
            return redirect()->route('home.edit', $id);
        }
    }

    public function delete($id){
        $user = User::find($id);
        return view('home.delete', $user);
    }   

    public function destroy($id, Request $req){
        if(User::destroy($req->userId)){
            return redirect()->route('home.list');
        }else{
            return redirect()->route('home.delete', $id);
        }
    }

    public function list(){
        //$students = $this->getStudentList();
        $users = User::all();
        return view('home.viewUsers', ['users'=>$users]);
    }

   
}
