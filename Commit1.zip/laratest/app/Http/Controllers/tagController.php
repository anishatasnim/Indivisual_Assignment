<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;

class tagController extends Controller
{
    public function index(Request $req){
    	$category = DB::table('category')->get();
    	return view('home.all_tag',compact('category'));

    }
    public function storetag(Request $req){
    	$data=array();
    	$data['title']=$req->title;
    	$data['category_id']=$req->category_id;
    	$data['details']=$req->details;
    	DB::table('tag')->insert($data);
    	return Redirect()->back();

    	}

    
    public function all(){
        // $post=DB::table('post')->get();
        $post=DB::table('tag')
        ->join('category','tag.category_id','category.id')
        ->select('tag.*','category.category_name')
        ->get();

        return view('home.show_all_tag',compact('tag'));
    }
    public function viewtag($id){
        $post=DB::table('tag')
        ->join('category','tag.category_id','category.id')
        ->select('tag.*','category.category_name')
        ->where('tag.id',$id)
        ->first();
        // print_r($post);
        return view('home.view_tag',compact('tag'));
    }
    public function edit($id){
        
        $post=DB::table('tag')->where('id',$id)->first();
        $category=DB::table('category')->get();
        return view('home.edit_tag',compact('category','tag'));
    }
    public function update(Request $req,$id){
        $data=array();
        $data['title']=$req->title;
        $data['category_id']=$req->category_id;
        $data['details']=$req->details;
          
            DB::table('tag')->where('id',$id)->update($data);
            return Redirect()->route('tag.all');

        }

    }
    public function delete($id){
        $delete=DB::table('tag')->where('id',$id)->delete();
        return Redirect()->route('tag.all');

    }
}
