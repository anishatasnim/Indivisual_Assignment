<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//login
Route::get('/login','LoginController@index');
Route::post('/login','LoginController@verify');
//logout
Route::get('/logout','LogoutController@index');
//admin
Route::get('/adminhome','HomeController@index')->name('home.index');
Route::get('/adminhome/viewUsers', 'HomeController@list')->name('home.list');
Route::get('/adminhome/addNewUser','HomeController@addUser')->name('home.addUser');
Route::post('/adminhome/addNewUser','HomeController@addUser');
Route::get('/adminhome/deleteUsers', 'HomeController@delete')->name('home.delete');

//post
Route::get('/post','postController@index')->name('post.index');
Route::get('/viewpost{id}','postController@viewpost')->name('post.view');
Route::get('/deletepost{id}','postController@delete')->name('post.delete');
Route::get('/editpost{id}','postController@edit')->name('post.edit');
Route::post('/updatepost{id}','postController@update');



//user
Route::get('/userhome','HomeController@index')->name('user.index');
