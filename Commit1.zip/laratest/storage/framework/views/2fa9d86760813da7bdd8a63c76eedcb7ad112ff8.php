<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Welcome Home! </h1>&nbsp


	<a href="<?php echo e(route('home.list')); ?>">View Users</a> |<a href="<?php echo e(route('post.index')); ?>">Write Post</a>|<a href="<?php echo e(route('post.all')); ?>">All Post</a> |<a href="<?php echo e(route('home.addUser')); ?>">Add New users </a>|<a href="<?php echo e(route('home.delete')); ?>">Delete users </a>|<a href="<?php echo e(route('post.all')); ?>">All Post</a> <br>
	<a href="/logout">Logout</a> 

</body>
</html><?php /**PATH D:\Spring 2020\Final\ATP 3\laratest\resources\views/home/index.blade.php ENDPATH**/ ?>