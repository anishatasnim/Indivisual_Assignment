<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body>
	<h1>Login Page</h1>
	<form method="post" >
		<?php echo csrf_field(); ?>
<!-- 		<?php echo e(csrf_field()); ?> -->		
<!-- 		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> -->
		Name    : <input type="text" name="name" > <br>
		Username: <input type="text" name="uname" > <br>
		Password: <input type="password" name="password" ><br>
		Gender  : <input type="text" name="gender" ><br>
		Email   : <input type="text" name="email" > <br>
		Type    : <input type="text" name="type" ><br>
		<input type="submit" name="submit" value="Submit" >
	</form>

	<h3><?php echo e(session('msg')); ?></h3>
</body>
</html><?php /**PATH D:\Spring 2020\Final\ATP 3\laratest\resources\views/home/addUser.blade.php ENDPATH**/ ?>