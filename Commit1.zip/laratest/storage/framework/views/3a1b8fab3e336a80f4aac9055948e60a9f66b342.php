<!DOCTYPE html>
<html>
<head>
	<title>User List</title>
</head>
<body>	

	<h1>All User List</h1>&nbsp
	<a href="<?php echo e(route('home.index')); ?>">back</a> |
	<a href="/logout">Logout</a> 

	<table border="1">
		<tr>
			<th>ID</th>
			<th>User Name</th>
			<th>Name</th>
			<th>Gender</th>
			<th>EMAIL</th>
			<th>ACCOUNT TYPE</th>
			<!-- <th>Action</th> -->
		</tr>
		
		 <?php for($i = 0; $i < count($users); $i++): ?>
        <tr>
            <td><?php echo e($users[$i]->id); ?></td>
            <td><?php echo e($users[$i]->uname); ?></td>
            <td><?php echo e($users[$i]->name); ?></td>
            <td><?php echo e($users[$i]->gender); ?></td>
            <td><?php echo e($users[$i]->email); ?></td>
            <td><?php echo e($users[$i]->type); ?></td>
        </tr>
    <?php endfor; ?>
	</table>

</body>
</html><?php /**PATH D:\Spring 2020\Final\ATP 3\laratest\resources\views/home/viewUsers.blade.php ENDPATH**/ ?>