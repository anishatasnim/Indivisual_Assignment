<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body>
	<h1>Login Page</h1>
	<a href="{{route('home.list')}}">Back</a> |
	<a href="/logout">Logout</a> <br>

	<form method="post" enctype="multipart/form-data">
		@csrf
<!-- 		{{csrf_field()}} -->		
<!-- 		<input type="hidden" name="_token" value="{{csrf_token()}}"> -->
		
		Username: <input type="text" name="uname" > <br>
		Password: <input type="password" name="password" ><br>
		Gender  : <input type="text" name="gender" ><br>
		Email   : <input type="text" name="email" > <br>
		Type    : <input type="text" name="type" ><br>
		<input type="submit" name="submit" value="Submit" >
	</form>

	<h3>{{session('msg')}}</h3>
</body>
</html>