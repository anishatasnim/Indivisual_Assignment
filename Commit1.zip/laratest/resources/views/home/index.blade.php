<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Welcome Home! </h1>&nbsp


	<a href="{{route('home.list')}}">View Users</a> |<a href="{{route('post.index')}}">Write Post</a>|<a href="{{route('post.all')}}">All Post</a> |<a href="{{route('home.addUser')}}">Add New users </a>|<a href="{{route('home.delete')}}">Delete users </a>|<a href="{{route('post.all')}}">All Post</a> <br>
	<a href="/logout">Logout</a> 

</body>
</html>