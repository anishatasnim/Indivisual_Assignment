<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Welcome Home! </h1>&nbsp


	
	


	<a href="{{route('home.list')}}">View Users</a> |<a href="{{route('post.index')}}">Write Post</a>|<a href="{{route('post.all')}}">All Post</a>|<a href="{{route('catagory.index')}}">Categories</a>| <a href="{{route('catagory.all')}}">All Categories</a> <br>
	<a href="/logout">Logout</a> 

</body>
</html>