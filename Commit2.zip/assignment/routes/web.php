<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//login
Route::get('/login','LoginController@index');
Route::post('/login','LoginController@verify');
//logout
Route::get('/logout','LogoutController@index');
//admin
Route::get('/adminhome','HomeController@index')->name('home.index');
Route::get('/adminhome/viewUsers', 'HomeController@list')->name('home.list');
Route::get('/adminhome/addNewUser','HomeController@addUser')->name('home.addUser');
Route::post('/adminhome/addNewUser','HomeController@insert');
Route::get('/adminhome/deleteUsers', 'HomeController@delete')->name('home.delete');

//category
Route::get('/category','categoryController@index')->name('category.index');
Route::get('/category/viewCategory', 'categoryController@list')->name('category.list');
Route::get('/category/createCategory','categoryController@addCategory')->name('category.addCategory');
Route::post('/category/edit','categoryController@update')->name('category.edit');
Route::get('/category/delete', 'categoryController@delete')->name('category.delete');


//tag
Route::get('/tag','tagController@index')->name('tag.index');
Route::get('/tag/viewTag', 'tagController@list')->name('tag.list');
Route::get('/tag/createTag','tagController@addTag')->name('tag.addTag');
Route::post('/tag/edit','tagController@update')->name('tag.edit');
Route::get('/tag/delete', 'tagController@delete')->name('tag.delete');



//user
Route::get('/userhome','HomeController@index')->name('user.index');
