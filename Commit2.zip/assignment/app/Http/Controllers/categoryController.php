<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\HomeRequest;
use Validator;

class categoryController extends Controller
{

    public function index(Request $req){

        
        if($req->session()->has('uname')){
            return view('category.index');
        }else{
            return redirect('/login');
        }
    }   

    public function show($id){

        $user = User::find($id);
        return view('home.details', $user);
    }
    
    public function addCategory(Request $req){

        /*$data=array();
        
        $data['uname']=$req->uname;
        $data['password']=$req->password;
        $data['gender']=$req->gender;
        $data['email']=$req->email;
        $data['type']=$req->type;
        DB::table('users')->insert($data);
       if($data->save()){
            return redirect()->route('home.list');
        }else{
            return redirect()->route('home.index');
        }*/
        return view('home.addCategory');

    }

    public function insert(Request $req){

        $req->validate([
            'title'=>'required|min:5',
            'description'=>'required',
            /*'gender' => 'required',
            'email'    =>'required',
            'typr' =>'required'*/
        ]);

        $user = DB::table('categories')->get();
        return view('category.list');

        /*$validation = $this->validate($req, [
            'username'=>'bail|required|min:5|unique:users',
            'password'=>'required',
            'name'=>'required',
            'cgpa'=>'required'
        ])->validate();*/

        //$validation->validate();

/*      $validation = Validator::make($req->all(), [
            'username'=>'bail|required|min:5|unique:users',
            'password'=>'required',
            'name'=>'required',
            'cgpa'=>'required'
        ]);

        if($validation->fails()){
            return back()
                    ->with('errors', $validation->errors())
                    ->withInput();

            return redirect()->route('home.add')
                            ->with('errors', $validation->errors())
                            ->withInput();      
        }*/

        $category           = new category;
        $category->title = $req->title;
        $category->description = $req->description;
        /*$user->gender   = $req->gender;
        $user->email    = $req->email;
        $user->type     = $req->type;*/


        if($category->save()){
            return redirect()->route('category.list');
        }else{
            return redirect()->route('category.addCategory');
        }
    }

    public function edit($id){
    
        /*$students = $this->getStudentList();
        $std="";
        for($i=0; $i< count($students); $i++){
            if($students[$i]['id'] == $id){
                $std = $students[$i];
                break;
            }
        }*/

        $category = category::find($id);
        return view('category.edit', $category);
    }

    public function update($id, Request $req){
        $category = category::find($id);
        $category->title = $req->title;
        $category->description = $req->description;
        /*$user->gender   = $req->gender;
        $user->email    = $req->email;
        $user->type     = $req->type;
        */
        
        if($category->save()){
            return redirect()->route('category.list');
        }else{
            return redirect()->route('category.edit', $id);
        }
    }

    public function delete($id){
        $category = category::find($id);
        return view('category.delete', $category);
    }   

    public function destroy($id, Request $req){
        if(category::destroy($req->id)){
            return redirect()->route('category.list');
        }else{
            return redirect()->route('category.delete', $id);
        }
    }

    public function list(){
        //$students = $this->getStudentList();
        $category = category::all();
        return view('category.viewCategory', ['categories'=>$categories]);
    }

   
}
