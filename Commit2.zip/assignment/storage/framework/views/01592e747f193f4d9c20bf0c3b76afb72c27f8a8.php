<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Welcome Home! </h1>&nbsp
	
	<a href="<?php echo e(route('home.list')); ?>">View Users</a> |<a href="<?php echo e(route('category.list')); ?>">View Categories</a>|<a href="<?php echo e(route('category.addCategory')); ?>">Create Categories</a>|<a href="<?php echo e(route('category.edit')); ?>">Update Categories</a>|<a href="<?php echo e(route('category.delete')); ?>">Delete Categories</a>|
	 <a href="<?php echo e(route('tag.list')); ?>">View Tag</a>|<a href="<?php echo e(route('tag.addTag')); ?>">Create Tag</a>|<a href="<?php echo e(route('tag.edit')); ?>">Update tag</a>|<a href="<?php echo e(route('tag.delete')); ?>">Delete Tag</a>| 
	<a href="/logout">Logout</a> 

</body>
</html><?php /**PATH D:\Spring 2020\Final\ATP 3\assignment\resources\views/home/index.blade.php ENDPATH**/ ?>