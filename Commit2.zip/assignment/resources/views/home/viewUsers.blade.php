<!DOCTYPE html>
<html>
<head>
	<title>User List</title>
</head>
<body>	

	<h1>All User List</h1>&nbsp
	<a href="{{route('home.index')}}">back</a> |
	<a href="/logout">Logout</a> 

	<table border="1">
		<tr>
			<th>ID</th>
			<th>User Name</th>
			<th>Gender</th>
			<th>EMAIL</th>
			<th>ACCOUNT TYPE</th>
			<!-- <th>Action</th> -->
		</tr>
		
		 @for($i = 0; $i < count($users); $i++)
        <tr>
            <td>{{ $users[$i]->id }}</td>
            <td>{{ $users[$i]->uname }}</td>
            <td>{{ $users[$i]->gender }}</td>
            <td>{{ $users[$i]->email }}</td>
            <td>{{ $users[$i]->type }}</td>
        </tr>
    @endfor
	</table>

</body>
</html>