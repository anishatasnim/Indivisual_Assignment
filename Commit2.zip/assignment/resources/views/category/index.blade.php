<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Welcome Home! </h1>&nbsp

	<a href="{{route('category.add')}}">Create Category</a> |
	<a href="{{route('category.list')}}">View Ctaegory</a> |
	<a href="{{route('category.delete')}}">Delete Category</a> |
	<a href="{{route('category.edit')}}">Edit Ctaegory</a> 
	<a href="/logout">Logout</a> 

</body>
</html>