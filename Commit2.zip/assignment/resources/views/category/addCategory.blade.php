<!DOCTYPE html>
<html>
<head>
	<title>Add Category</title>
</head>
<body>	

	<h1>Create Category</h1>&nbsp
	<a href="{{route('category.list')}}">Back</a> |
	<a href="/logout">Logout</a> <br>

	<form method="post" enctype="multipart/form-data">
		{{csrf_field()}}
		<table>
			<tr>
				<td>Title</td>
				<td><input type="text" name="title"></td>
			</tr>

			<tr>
				<td>Description</td>
				<td><input type="text" name="description"></td>
			</tr>
			
		</table>
	</form>
	
	@foreach($errors->all() as $err)
		{{$err}} <br>
	@endforeach

</body>
</html>