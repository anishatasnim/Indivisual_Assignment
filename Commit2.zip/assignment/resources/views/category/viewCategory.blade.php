<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Welcome Home!</h1>&nbsp
	<a href="{{route('category.index')}}">back</a> |
	<a href="/logout">Logout</a> 

	<table border="1">
		<tr>
			<th>ID</th>
			<th>TITLE</th>
			<th>DESCRIPTION</th>
			
		</tr>
		
		@foreach($categories as $category)
		<tr>
			<td>{{$category['id']}}</td>
			<td>{{$category['title']}}</td>
			<td>{{$category['description']}}</td>
			<td>
				<a href="{{route('category.edit', $category['id'])}}">Edit</a> | 
				<a href="{{route('category.delete', $category['id'])}}">Delete</a> |
				<a href="{{route('category.show', $category['id'])}}">Details</a> 
			</td>
		</tr>
		@endforeach
	</table>

</body>
</html>