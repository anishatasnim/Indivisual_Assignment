<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Welcome Home! </h1>&nbsp
	
	<a href="{{route('home.list')}}">View Users</a> |<a href="{{route('category.list')}}">View Categories</a>|<a href="{{route('category.add)}}">Create Categories</a>|<a href="{{route('category.update')}}">Update Categories</a>|<a href="{{route('catagory.delete')}}">Delete Categories</a>|
	 <a href="{{route('tag.list')}}">View Tag</a>|<a href="{{route('tag.add)}}">Create Tag</a>|<a href="{{route('tag.update')}}">Update tag</a>|<a href="{{route('tag.delete')}}">Delete Tag</a>| 
	<a href="/logout">Logout</a> 

</body>
</html>