<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Tag Details</h1>&nbsp
	<a href="/logout">Logout</a> <br>

		<table>
			<tr>
				<td>Id</td>
				<td>{{$id}}</td>
			</tr>
			<tr>
				<td>Title</td>
				<td>{{$title}}</td>
			</tr>
			<tr>
				<td>Description</td>
				<td>{{$description}}</td>
			</tr>
			

		</table>
		<h2>Are you sure? This can't be undone!</h2>
		<form method="post">
			{{csrf_field()}}
			<input type="hidden" name="id" value="{{$id}}">
			<input type="submit" name="submit" value="Confirm">
		</form>
</body>
</html>