<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Welcome Home!</h1>&nbsp
	<a href="{{route('tag.index')}}">back</a> |
	<a href="/logout">Logout</a> 

	<table border="1">
		<tr>
			<th>ID</th>
			<th>TITLE</th>
			<th>DESCRIPTION</th>
			
		</tr>
		
		@foreach($tags as $tag)
		<tr>
			<td>{{$tag['id']}}</td>
			<td>{{$tag['title']}}</td>
			<td>{{$tag['description']}}</td>
			<td>
				<a href="{{route('tag.edit', $tag['id'])}}">Edit</a> | 
				<a href="{{route('tag.delete', $tag['id'])}}">Delete</a> |
				<a href="{{route('tag.show', $tag['id'])}}">Details</a> 
			</td>
		</tr>
		@endforeach
	</table>

</body>
</html>