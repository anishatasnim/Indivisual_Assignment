<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Welcome Home! </h1>&nbsp

	<a href="{{route('tag.add')}}">Create Add</a> |
	<a href="{{route('tag.list')}}">View Tag</a> |
	<a href="{{route('tag.delete')}}">Delete Tag</a> |
	<a href="{{route('tag.edit')}}">Edit Tag</a> 
	<a href="/logout">Logout</a> 

</body>
</html>